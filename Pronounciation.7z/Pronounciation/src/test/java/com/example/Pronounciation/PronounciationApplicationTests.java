package com.example.Pronounciation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PronounciationApplicationTests {

	@Test
	void contextLoads() {
	}

}
