package com.example.Pronounciation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PronounciationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PronounciationApplication.class, args);
	}

}
